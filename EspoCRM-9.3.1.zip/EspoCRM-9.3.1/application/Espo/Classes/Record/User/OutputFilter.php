<?php
/************************************************************************
 * This file is part of EspoCRM.
 *
 * EspoCRM – Open Source CRM application.
 * Copyright (C) 2014-2026 EspoCRM, Inc.
 * Website: https://www.espocrm.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "EspoCRM" word.
 ************************************************************************/

namespace Espo\Classes\Record\User;

use Espo\Core\Authentication\Logins\Hmac;
use Espo\Core\Record\Output\Filter;
use Espo\Core\Utils\ApiKey;
use Espo\Entities\User;
use Espo\ORM\Entity;

/**
 * @implements Filter<User>
 */
class OutputFilter implements Filter
{
    public function __construct(
        private User $user,
        private ApiKey $apiKey
    ) {}

    public function filter(Entity $entity): void
    {
        $entity->clear('sendAccessInfo');

        $this->filterApiUser($entity);
    }

    private function filterApiUser(User $entity): void
    {
        if (!$entity->isApi()) {
            return;
        }

        if ($this->user->isAdmin()) {
            if ($entity->getAuthMethod() === Hmac::NAME) {
                $secretKey = $this->apiKey->getSecretKeyForUserId($entity->getId());

                $entity->set('secretKey', $secretKey);
            }

            return;
        }

        $entity->clear('apiKey');
        $entity->clear('secretKey');
    }
}
